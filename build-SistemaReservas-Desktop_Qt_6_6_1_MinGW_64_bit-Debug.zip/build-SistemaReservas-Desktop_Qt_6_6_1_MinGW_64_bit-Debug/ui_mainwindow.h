/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QPushButton *btnCrearReserva;
    QPushButton *btnConsultarDisponibilidad;
    QPushButton *btnModificarReserva;
    QPushButton *btnCancelarReserva;
    QLabel *label;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(1140, 644);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        btnCrearReserva = new QPushButton(centralwidget);
        btnCrearReserva->setObjectName("btnCrearReserva");
        btnCrearReserva->setGeometry(QRect(470, 150, 181, 29));
        btnConsultarDisponibilidad = new QPushButton(centralwidget);
        btnConsultarDisponibilidad->setObjectName("btnConsultarDisponibilidad");
        btnConsultarDisponibilidad->setGeometry(QRect(470, 200, 181, 29));
        btnModificarReserva = new QPushButton(centralwidget);
        btnModificarReserva->setObjectName("btnModificarReserva");
        btnModificarReserva->setGeometry(QRect(470, 250, 181, 29));
        btnCancelarReserva = new QPushButton(centralwidget);
        btnCancelarReserva->setObjectName("btnCancelarReserva");
        btnCancelarReserva->setGeometry(QRect(470, 300, 181, 29));
        label = new QLabel(centralwidget);
        label->setObjectName("label");
        label->setGeometry(QRect(460, 70, 451, 81));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 1140, 25));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        btnCrearReserva->setText(QCoreApplication::translate("MainWindow", "Crear Reserva", nullptr));
        btnConsultarDisponibilidad->setText(QCoreApplication::translate("MainWindow", "Consultar Disponibilidad", nullptr));
        btnModificarReserva->setText(QCoreApplication::translate("MainWindow", "Modificar Reserva", nullptr));
        btnCancelarReserva->setText(QCoreApplication::translate("MainWindow", "Cancelar Reserva", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:16pt;\">                         Sistema de Reservas</span></p></body></html>", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
